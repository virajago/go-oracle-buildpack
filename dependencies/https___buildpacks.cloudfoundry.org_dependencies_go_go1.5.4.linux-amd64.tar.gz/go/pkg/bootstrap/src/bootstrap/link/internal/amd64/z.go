// Do not edit. Bootstrap copy of /tmp/x86_64-linux-gnu/ports/go/1.5.4/go/src/cmd/link/internal/amd64/z.go

//line /tmp/x86_64-linux-gnu/ports/go/1.5.4/go/src/cmd/link/internal/amd64/z.go:1
package amd64
